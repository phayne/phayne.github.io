---
layout: page
title: Mars
permalink: /research/mars/
description: Martian surface and atmospheric processes
---

<style>
.research-content {
  line-height: 1.7;
}
.research-content h2 {
  margin-top: 2rem;
  margin-bottom: 0.8rem;
  font-size: 1.3rem;
  border-bottom: 1px solid #ddd;
  padding-bottom: 0.3rem;
}
.research-content p {
  margin-bottom: 1rem;
}
.back-link {
  margin-top: 2rem;
  font-size: 0.9rem;
}
.back-link a {
  color: #0066cc;
  text-decoration: none;
}
.back-link a:hover {
  text-decoration: underline;
}
</style>

<div class="research-content">

Mars presents a rich environment for studying ice and volatile processes, from seasonal CO₂ frost cycles to ancient water-carved terrain. Our research focuses on understanding the current and past distribution of water and ice on the Martian surface.

## Polar Ice Caps

The Martian polar regions contain vast reservoirs of water ice covered by seasonal CO₂ frost. We study the thermal properties and layering of these deposits to understand Mars' climate history and the processes that shape the polar landscape today.

## Surface Thermophysical Properties

Using thermal infrared observations from orbit, we characterize the physical properties of the Martian surface. These measurements reveal information about rock abundance, dust cover, and subsurface ice that inform our understanding of surface processes and potential resources.

## Seasonal Frost Cycles

Mars experiences dramatic seasonal changes as CO₂ condenses and sublimes at the polar caps and in shaded regions. Our thermal models help interpret these cycles and their effects on surface properties.

## Related Missions

- [Mars Reconnaissance Orbiter](/research/missions/#mro)

</div>

<div class="back-link">
  ← <a href="/research/">Back to Research</a>
</div>
