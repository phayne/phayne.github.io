---
layout: page
title: Missions
permalink: /research/missions/
description: Spacecraft missions and instrument involvement
---

<style>
.missions-content {
  line-height: 1.7;
}
.mission-group {
  margin-bottom: 2.5rem;
}
.mission-group h2 {
  font-size: 1.3rem;
  border-bottom: 2px solid #333;
  padding-bottom: 0.3rem;
  margin-bottom: 1.2rem;
}
.mission-entry {
  margin-bottom: 1.8rem;
  padding-left: 1rem;
  border-left: 3px solid #ddd;
}
.mission-entry h3 {
  font-size: 1.1rem;
  margin-bottom: 0.4rem;
  margin-top: 0;
}
.mission-entry h3 a {
  color: #0066cc;
  text-decoration: none;
}
.mission-entry h3 a:hover {
  text-decoration: underline;
}
.mission-meta {
  font-size: 0.85rem;
  color: #666;
  margin-bottom: 0.5rem;
}
.mission-entry p {
  margin: 0;
  font-size: 0.95rem;
}
.back-link {
  margin-top: 2rem;
  font-size: 0.9rem;
}
.back-link a {
  color: #0066cc;
  text-decoration: none;
}
.back-link a:hover {
  text-decoration: underline;
}
</style>

<div class="missions-content">

Our group is involved in a range of NASA and international missions, contributing to instrument development, science planning, and data analysis.

<!-- MOON MISSIONS -->
<div class="mission-group">
<h2>Moon</h2>

<div class="mission-entry" id="lro">
<h3><a href="https://lunar.gsfc.nasa.gov/about.html" target="_blank">Lunar Reconnaissance Orbiter (LRO)</a></h3>
<div class="mission-meta">NASA · Launched 2009 · Ongoing operations</div>
<p>LRO has been mapping the Moon in unprecedented detail since 2009. Our group uses data from the Diviner Lunar Radiometer Experiment to study thermal properties of the lunar surface, characterize permanently shadowed regions, and map potential water ice deposits at the poles.</p>
</div>

<div class="mission-entry" id="lunar-flashlight">
<h3><a href="https://www.jpl.nasa.gov/missions/lunar-flashlight" target="_blank">Lunar Flashlight</a></h3>
<div class="mission-meta">NASA JPL · Launched 2022</div>
<p>Lunar Flashlight was a small satellite mission designed to search for surface water ice in permanently shadowed craters using near-infrared lasers. Our group contributed to mission planning and data analysis strategies for detecting water ice signatures.</p>
</div>

<div class="mission-entry" id="lunar-vise">
<h3>CLPS CP-21: Lunar-VISE</h3>
<div class="mission-meta">NASA Commercial Lunar Payload Services</div>
<p>The Lunar Vulkan Imaging and Spectroscopy Explorer (Lunar-VISE) will investigate the Gruithuisen Domes, enigmatic volcanic features on the Moon. Our involvement focuses on understanding the thermal environment and surface properties of these unique geological formations.</p>
</div>

<div class="mission-entry" id="l-ciris">
<h3>CLPS CP-22: L-CIRiS</h3>
<div class="mission-meta">NASA Commercial Lunar Payload Services</div>
<p>The Lunar Compact Infrared Imaging System (L-CIRiS) is a thermal camera that will provide high-resolution temperature measurements of the lunar surface. These data will reveal fine-scale thermal properties and help characterize potential landing and exploration sites.</p>
</div>

<div class="mission-entry" id="l-maps">
<h3>Lunar Terrain Vehicle Instruments: L-MAPS</h3>
<div class="mission-meta">NASA Artemis Program</div>
<p>The Lunar Mapping and Prospecting System (L-MAPS) is being developed for NASA's Lunar Terrain Vehicle. This instrument suite will provide in-situ measurements of surface composition and thermal properties to support Artemis astronaut exploration activities.</p>
</div>

</div>

<!-- MARS MISSIONS -->
<div class="mission-group">
<h2>Mars</h2>

<div class="mission-entry" id="mro">
<h3><a href="https://mars.nasa.gov/mro/" target="_blank">Mars Reconnaissance Orbiter (MRO)</a></h3>
<div class="mission-meta">NASA · Launched 2005 · Ongoing operations</div>
<p>MRO carries a suite of instruments that have revolutionized our understanding of Mars. Our research uses thermal infrared data to study surface properties, seasonal frost cycles, and the distribution of subsurface ice across the Martian surface.</p>
</div>

</div>

<!-- ASTEROID MISSIONS -->
<div class="mission-group">
<h2>Asteroids</h2>

<div class="mission-entry" id="ema">
<h3><a href="https://www.emiratesmarsmission.ae/ema" target="_blank">Emirates Mission to the Asteroid Belt (EMA)</a></h3>
<div class="mission-meta">UAE Space Agency · In development</div>
<p>EMA will explore multiple main belt asteroids, providing new insights into the diversity of small bodies in our solar system. Our group contributes to thermal modeling and science planning for this ambitious mission.</p>
</div>

<div class="mission-entry" id="janus">
<h3>Janus</h3>
<div class="mission-meta">NASA SIMPLEx Mission</div>
<p>Janus was designed to study binary asteroid systems, providing insights into the formation and evolution of small bodies. Our involvement focused on thermal modeling of asteroid surfaces and understanding heat transfer in low-gravity environments.</p>
</div>

<div class="mission-entry" id="dawn">
<h3><a href="https://solarsystem.nasa.gov/missions/dawn/overview/" target="_blank">Dawn</a></h3>
<div class="mission-meta">NASA · 2007–2018</div>
<p>Dawn explored the two largest objects in the asteroid belt: Vesta and Ceres. Our research used Dawn data to study the thermal properties and surface composition of these protoplanets, including the detection of water ice on Ceres.</p>
</div>

</div>

<!-- OUTER SOLAR SYSTEM MISSIONS -->
<div class="mission-group">
<h2>Outer Solar System</h2>

<div class="mission-entry" id="europa-clipper">
<h3><a href="https://europa.nasa.gov/" target="_blank">Europa Clipper</a></h3>
<div class="mission-meta">NASA · Launched 2024 · En route to Jupiter</div>
<p>Europa Clipper will conduct detailed reconnaissance of Jupiter's moon Europa to investigate whether it could harbor conditions suitable for life. Our group contributes to thermal modeling and surface composition studies in preparation for the mission's arrival at Jupiter.</p>
</div>

<div class="mission-entry" id="cassini">
<h3><a href="https://solarsystem.nasa.gov/missions/cassini/overview/" target="_blank">Cassini</a></h3>
<div class="mission-meta">NASA/ESA · 1997–2017</div>
<p>Cassini spent 13 years exploring the Saturn system, transforming our understanding of the ringed planet and its moons. Our research uses Cassini data to study Titan's atmosphere, Enceladus's thermal emission, and the surface properties of Saturn's icy satellites.</p>
</div>

<div class="mission-entry" id="galileo">
<h3><a href="https://solarsystem.nasa.gov/missions/galileo/overview/" target="_blank">Galileo</a></h3>
<div class="mission-meta">NASA · 1989–2003</div>
<p>Galileo was the first spacecraft to orbit Jupiter, providing groundbreaking observations of the giant planet and its moons. Our research uses Galileo data to study Europa's surface composition and thermal properties, laying the groundwork for future exploration.</p>
</div>

</div>

</div>

<div class="back-link">
  ← <a href="/research/">Back to Research</a>
</div>
