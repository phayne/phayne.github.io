---
layout: page
title: Asteroids & Comets
permalink: /research/asteroids/
description: Small bodies and primitive materials in the solar system
---

<style>
.research-content {
  line-height: 1.7;
}
.research-content h2 {
  margin-top: 2rem;
  margin-bottom: 0.8rem;
  font-size: 1.3rem;
  border-bottom: 1px solid #ddd;
  padding-bottom: 0.3rem;
}
.research-content p {
  margin-bottom: 1rem;
}
.back-link {
  margin-top: 2rem;
  font-size: 0.9rem;
}
.back-link a {
  color: #0066cc;
  text-decoration: none;
}
.back-link a:hover {
  text-decoration: underline;
}
</style>

<div class="research-content">

Asteroids and comets preserve a record of conditions in the early solar system and represent the building blocks from which the planets formed. Our research investigates the surface properties and volatile content of these primitive bodies.

## Main Belt Asteroids

The asteroid belt between Mars and Jupiter contains a diverse population of rocky and ice-rich bodies. We use thermal modeling and spectroscopy to characterize their surface properties and understand their origins.

## Near-Earth Objects

Near-Earth asteroids provide opportunities for detailed study and potential resource utilization. Our research contributes to understanding their physical properties and thermal environments.

## Binary and Multiple Systems

Many asteroids exist in binary or multiple systems, offering unique opportunities to study their masses, densities, and formation histories. We investigate the thermal properties of these systems and their implications for asteroid evolution.

## Cometary Surfaces

Comets carry some of the most primitive materials in the solar system. Our thermal models help interpret observations of cometary surfaces and their activity cycles.

## Related Missions

- [Emirates Mission to the Asteroid Belt](/research/missions/#ema)
- [Janus](/research/missions/#janus)
- [Dawn](/research/missions/#dawn)

</div>

<div class="back-link">
  ← <a href="/research/">Back to Research</a>
</div>
