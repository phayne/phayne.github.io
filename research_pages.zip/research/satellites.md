---
layout: page
title: Satellites of the Giant Planets
permalink: /research/satellites/
description: Icy moons of Jupiter and Saturn
---

<style>
.research-content {
  line-height: 1.7;
}
.research-content h2 {
  margin-top: 2rem;
  margin-bottom: 0.8rem;
  font-size: 1.3rem;
  border-bottom: 1px solid #ddd;
  padding-bottom: 0.3rem;
}
.research-content p {
  margin-bottom: 1rem;
}
.back-link {
  margin-top: 2rem;
  font-size: 0.9rem;
}
.back-link a {
  color: #0066cc;
  text-decoration: none;
}
.back-link a:hover {
  text-decoration: underline;
}
</style>

<div class="research-content">

The icy moons of Jupiter and Saturn are among the most compelling targets in the search for habitable environments beyond Earth. Our research focuses on understanding the surface composition, thermal properties, and geological processes of these fascinating worlds.

## Europa

Jupiter's moon Europa harbors a global subsurface ocean beneath its icy shell. We study Europa's surface composition and thermal environment to understand the exchange between the ocean and surface, and to prepare for future exploration missions.

## Titan

Saturn's largest moon Titan has a dense atmosphere and surface lakes of liquid methane and ethane. Our research uses spectroscopic observations to probe Titan's atmospheric structure and surface-atmosphere interactions.

## Enceladus

The active plumes of Enceladus provide a window into the moon's subsurface ocean. We study the thermal emission from Enceladus to understand the heat sources driving this remarkable activity.

## Other Icy Moons

Our research extends to other satellites including Ganymede, Callisto, and the mid-sized moons of Saturn, each offering unique insights into ice-rich planetary bodies.

## Related Missions

- [Europa Clipper](/research/missions/#europa-clipper)
- [Cassini](/research/missions/#cassini)
- [Galileo](/research/missions/#galileo)

## Related Datasets

- [Cassini VIMS Titan occultation spectra](/research/datasets/cassini-vims-titan/)
- [Galileo NIMS Europa hyperspectral images](/research/datasets/galileo-nims-europa/)
- [Galileo PPR thermal maps](/research/datasets/galileo-ppr/)

</div>

<div class="back-link">
  ← <a href="/research/">Back to Research</a>
</div>
