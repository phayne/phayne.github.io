---
layout: page
title: LAMP Water Detections
permalink: /research/datasets/lamp-water/
description: Lunar water signatures from LRO LAMP UV spectrometer
---

<style>
.dataset-content {
  line-height: 1.7;
}
.dataset-content h2 {
  margin-top: 2rem;
  margin-bottom: 0.8rem;
  font-size: 1.2rem;
  border-bottom: 1px solid #ddd;
  padding-bottom: 0.3rem;
}
.dataset-content p {
  margin-bottom: 1rem;
}
.dataset-meta {
  background: #f5f5f5;
  padding: 1rem;
  border-radius: 6px;
  margin-bottom: 1.5rem;
  font-size: 0.9rem;
}
.dataset-meta dt {
  font-weight: 600;
  display: inline;
}
.dataset-meta dd {
  display: inline;
  margin-left: 0;
  margin-right: 1.5rem;
}
.placeholder-note {
  background: #fff3cd;
  border: 1px solid #ffc107;
  padding: 1rem;
  border-radius: 6px;
  font-size: 0.9rem;
}
.back-link {
  margin-top: 2rem;
  font-size: 0.9rem;
}
.back-link a {
  color: #0066cc;
  text-decoration: none;
}
.back-link a:hover {
  text-decoration: underline;
}
</style>

<div class="dataset-content">

<div class="dataset-meta">
  <dl>
    <dt>Source:</dt> <dd>LRO LAMP UV Spectrometer</dd>
    <dt>Coverage:</dt> <dd>Lunar polar regions</dd>
    <dt>Type:</dt> <dd>UV reflectance spectra</dd>
  </dl>
</div>

The Lyman Alpha Mapping Project (LAMP) instrument aboard LRO uses ultraviolet light to detect water frost signatures in permanently shadowed regions of the Moon. This dataset contains processed LAMP observations indicating potential surface water ice.

## Scientific Background

LAMP detects water by measuring how the lunar surface reflects far-ultraviolet light, including Lyman-alpha radiation from interplanetary hydrogen. Water ice has a distinctive UV spectral signature that differs from dry regolith, allowing LAMP to identify regions where frost may be present on the surface.

## Dataset Contents

*Details on data format and contents to be added.*

## Related Publications

- Hayne, P.O., et al. (2015). Evidence for exposed water ice in the Moon's south polar regions from Lunar Reconnaissance Orbiter ultraviolet albedo and temperature measurements. *Icarus*, 255, 58–69.

<div class="placeholder-note">
  <strong>Coming soon:</strong> This dataset is being prepared for public release. Please check back or contact us for access to preliminary data products.
</div>

</div>

<div class="back-link">
  ← <a href="/research/">Back to Research</a>
</div>
