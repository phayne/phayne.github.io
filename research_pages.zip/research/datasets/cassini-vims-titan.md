---
layout: page
title: Cassini VIMS Titan Occultation Spectra
permalink: /research/datasets/cassini-vims-titan/
description: Titan atmospheric spectra from Cassini VIMS solar occultations
---

<style>
.dataset-content {
  line-height: 1.7;
}
.dataset-content h2 {
  margin-top: 2rem;
  margin-bottom: 0.8rem;
  font-size: 1.2rem;
  border-bottom: 1px solid #ddd;
  padding-bottom: 0.3rem;
}
.dataset-content p {
  margin-bottom: 1rem;
}
.dataset-meta {
  background: #f5f5f5;
  padding: 1rem;
  border-radius: 6px;
  margin-bottom: 1.5rem;
  font-size: 0.9rem;
}
.dataset-meta dt {
  font-weight: 600;
  display: inline;
}
.dataset-meta dd {
  display: inline;
  margin-left: 0;
  margin-right: 1.5rem;
}
.placeholder-note {
  background: #fff3cd;
  border: 1px solid #ffc107;
  padding: 1rem;
  border-radius: 6px;
  font-size: 0.9rem;
}
.back-link {
  margin-top: 2rem;
  font-size: 0.9rem;
}
.back-link a {
  color: #0066cc;
  text-decoration: none;
}
.back-link a:hover {
  text-decoration: underline;
}
</style>

<div class="dataset-content">

<div class="dataset-meta">
  <dl>
    <dt>Source:</dt> <dd>Cassini VIMS</dd>
    <dt>Target:</dt> <dd>Titan atmosphere</dd>
    <dt>Type:</dt> <dd>Solar occultation spectra</dd>
    <dt>Wavelength:</dt> <dd>0.35–5.1 μm</dd>
  </dl>
</div>

Solar occultation observations by the Visual and Infrared Mapping Spectrometer (VIMS) aboard Cassini provide detailed information about Titan's atmospheric structure and composition. As the Sun passed behind Titan as viewed from Cassini, VIMS recorded how sunlight was absorbed and scattered at different altitudes.

## Scientific Background

Titan's thick atmosphere is rich in nitrogen, methane, and complex organic molecules. Solar occultations allow us to measure the vertical distribution of these species and study atmospheric haze layers with high precision. These measurements are essential for understanding Titan's atmospheric chemistry and climate.

## Dataset Contents

This dataset includes processed VIMS solar occultation spectra with:

- Calibrated transmission spectra as a function of altitude
- Retrieved atmospheric profiles
- Associated geometric and timing information

*Detailed format documentation to be provided with data release.*

## Related Publications

- Maltagliati, L., et al. (2015). Titan's haze variations from Cassini VIMS solar occultations. *Icarus*, 248, 1–24.

<div class="placeholder-note">
  <strong>Coming soon:</strong> This dataset is being prepared for public release. Please check back or contact us for access.
</div>

</div>

<div class="back-link">
  ← <a href="/research/">Back to Research</a>
</div>
