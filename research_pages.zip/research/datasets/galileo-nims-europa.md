---
layout: page
title: Galileo NIMS Europa Hyperspectral Images
permalink: /research/datasets/galileo-nims-europa/
description: Europa surface composition data from Galileo NIMS
---

<style>
.dataset-content {
  line-height: 1.7;
}
.dataset-content h2 {
  margin-top: 2rem;
  margin-bottom: 0.8rem;
  font-size: 1.2rem;
  border-bottom: 1px solid #ddd;
  padding-bottom: 0.3rem;
}
.dataset-content p {
  margin-bottom: 1rem;
}
.dataset-meta {
  background: #f5f5f5;
  padding: 1rem;
  border-radius: 6px;
  margin-bottom: 1.5rem;
  font-size: 0.9rem;
}
.dataset-meta dt {
  font-weight: 600;
  display: inline;
}
.dataset-meta dd {
  display: inline;
  margin-left: 0;
  margin-right: 1.5rem;
}
.placeholder-note {
  background: #fff3cd;
  border: 1px solid #ffc107;
  padding: 1rem;
  border-radius: 6px;
  font-size: 0.9rem;
}
.back-link {
  margin-top: 2rem;
  font-size: 0.9rem;
}
.back-link a {
  color: #0066cc;
  text-decoration: none;
}
.back-link a:hover {
  text-decoration: underline;
}
</style>

<div class="dataset-content">

<div class="dataset-meta">
  <dl>
    <dt>Source:</dt> <dd>Galileo NIMS</dd>
    <dt>Target:</dt> <dd>Europa surface</dd>
    <dt>Type:</dt> <dd>Hyperspectral imaging</dd>
    <dt>Wavelength:</dt> <dd>0.7–5.2 μm</dd>
  </dl>
</div>

The Near-Infrared Mapping Spectrometer (NIMS) aboard the Galileo spacecraft acquired hyperspectral images of Europa's surface, revealing the distribution of water ice, hydrated salts, and other materials that may originate from the subsurface ocean.

## Scientific Background

Europa's surface is predominantly water ice, but NIMS observations revealed compositional variations that provide clues about ocean-surface exchange. Non-ice materials, including hydrated sulfate and chloride salts, are concentrated in geologically disrupted "chaos" terrains, suggesting they may have been emplaced from below.

## Dataset Contents

This dataset includes reprocessed NIMS hyperspectral cubes with:

- Calibrated radiance and reflectance spectra
- Spectral parameter maps highlighting compositional variations
- Geographic registration to Europa base maps

*Detailed format documentation to be provided with data release.*

## Related Publications

- Dalton, J.B., et al. (2012). Europa's icy bright plains and dark linea: Exogenic and endogenic contributions to composition. *Journal of Geophysical Research*, 117, E03003.

<div class="placeholder-note">
  <strong>Coming soon:</strong> This dataset is being prepared for public release in support of Europa Clipper. Please check back or contact us for access.
</div>

</div>

<div class="back-link">
  ← <a href="/research/">Back to Research</a>
</div>
