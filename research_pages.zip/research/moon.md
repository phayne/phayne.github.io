---
layout: page
title: Moon
permalink: /research/moon/
description: Lunar surface processes, volatiles, and thermal properties
---

<style>
.research-content {
  line-height: 1.7;
}
.research-content h2 {
  margin-top: 2rem;
  margin-bottom: 0.8rem;
  font-size: 1.3rem;
  border-bottom: 1px solid #ddd;
  padding-bottom: 0.3rem;
}
.research-content p {
  margin-bottom: 1rem;
}
.back-link {
  margin-top: 2rem;
  font-size: 0.9rem;
}
.back-link a {
  color: #0066cc;
  text-decoration: none;
}
.back-link a:hover {
  text-decoration: underline;
}
</style>

<div class="research-content">

The Moon is a primary focus of our research, particularly understanding the distribution, stability, and accessibility of water ice and other volatiles in permanently shadowed regions near the lunar poles.

## Polar Volatiles

Water ice and other volatiles are trapped in permanently shadowed regions (PSRs) near the lunar poles, where temperatures can drop below 40 K. Our group uses thermal models and remote sensing data to map these cold traps and understand the processes that control volatile delivery, retention, and loss.

## Surface Thermophysical Properties

We use data from the Diviner Lunar Radiometer Experiment aboard the Lunar Reconnaissance Orbiter to characterize the thermal properties of the lunar regolith. These measurements reveal the structure and composition of the upper few centimeters of the surface, with implications for landing site selection and resource utilization.

## Micro Cold Traps

Our research has shown that water ice may be trapped in small-scale cold traps—shadows cast by rocks and small craters—that are far more numerous than the large permanently shadowed regions. These micro cold traps could significantly increase the accessible water inventory on the Moon.

## Related Missions

- [Lunar Reconnaissance Orbiter](/research/missions/#lro)
- [Lunar Flashlight](/research/missions/#lunar-flashlight)
- [CLPS CP-21: Lunar-VISE](/research/missions/#lunar-vise)
- [CLPS CP-22: L-CIRiS](/research/missions/#l-ciris)
- [Lunar Terrain Vehicle: L-MAPS](/research/missions/#l-maps)

## Related Datasets

- [Diviner H-parameter](/research/datasets/diviner-h-parameter/)
- [LAMP water detections](/research/datasets/lamp-water/)

</div>

<div class="back-link">
  ← <a href="/research/">Back to Research</a>
</div>
